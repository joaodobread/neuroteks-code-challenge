<?php

namespace App\Classes;

class Carro
{
    public function __construc()
    {
        echo "PORRA <br>";
    }
}
