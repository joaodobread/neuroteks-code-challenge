<?php

require_once "vendor/autoload.php";

use App\Classes\Carro;

$c = new Carro();

echo "ok";
